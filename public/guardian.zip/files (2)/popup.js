/* =========================================================================
 * Guardian Security Suite — popup.js
 *
 * >>> REPLACE <MY_VERCEL_URL> BELOW WITH YOUR ACTUAL DEPLOYED BACKEND URL <<<
 * Example: const API_BASE_URL = "https://guardian-api.vercel.app";
 * ========================================================================= */
const API_BASE_URL = "https://guradian.vercel.app/";

const ENDPOINTS = {
  checkUrl: `${API_BASE_URL}/api/check-url`,
  login: `${API_BASE_URL}/api/auth/login`,
  scan: `${API_BASE_URL}/api/scan`,
};

// ---------------------------------------------------------------------------
// DOM references
// ---------------------------------------------------------------------------
const el = (id) => document.getElementById(id);

const urlLoading = el("url-loading");
const urlResult = el("url-result");
const urlError = el("url-error");
const urlErrorText = el("url-error-text");
const urlDisplay = el("url-display");
const urlVerdictBanner = el("url-verdict-banner");
const urlVerdictIcon = el("url-verdict-icon");
const urlVerdictLabel = el("url-verdict-label");
const urlVerdictReason = el("url-verdict-reason");
const riskMeterFill = el("risk-meter-fill");
const riskScoreLabel = el("risk-score-label");
const urlRecheckBtn = el("url-recheck-btn");

const loginView = el("login-view");
const scanView = el("scan-view");
const loginForm = el("login-form");
const loginEmail = el("login-email");
const loginPassword = el("login-password");
const loginBtn = el("login-btn");
const loginError = el("login-error");
const loginErrorText = el("login-error-text");
const loggedInAs = el("logged-in-as");
const logoutBtn = el("logout-btn");

const fileInput = el("file-input");
const fileDropLabel = el("file-drop-label");
const fileDropText = el("file-drop-text");
const scanBtn = el("scan-btn");
const scanLoading = el("scan-loading");
const scanError = el("scan-error");
const scanErrorText = el("scan-error-text");
const scanResult = el("scan-result");
const scanVerdictBanner = el("scan-verdict-banner");
const scanVerdictIcon = el("scan-verdict-icon");
const scanVerdictLabel = el("scan-verdict-label");
const scanVerdictReason = el("scan-verdict-reason");
const scanFilename = el("scan-filename");
const scanClaimedType = el("scan-claimed-type");
const scanDetectedType = el("scan-detected-type");

let selectedFile = null;

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
  runUrlCheck();
  restoreAuthState();

  urlRecheckBtn.addEventListener("click", runUrlCheck);
  loginForm.addEventListener("submit", handleLogin);
  logoutBtn.addEventListener("click", handleLogout);
  fileInput.addEventListener("change", handleFileSelected);
  scanBtn.addEventListener("click", handleScanFile);
});

// =============================================================================
// FEATURE 1: URL Phishing Checker
// =============================================================================
async function runUrlCheck() {
  showUrlLoading();

  try {
    const tab = await getActiveTab();
    const currentUrl = tab && tab.url ? tab.url : null;

    if (!currentUrl || !/^https?:\/\//i.test(currentUrl)) {
      throw new Error("This page can't be scanned (not an http/https URL).");
    }

    urlDisplay.textContent = currentUrl;

    const response = await fetch(ENDPOINTS.checkUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: currentUrl }),
    });

    if (!response.ok) {
      throw new Error(`Backend returned status ${response.status}`);
    }

    // Expected shape: { safe: false, riskScore: 85, reason: "..." }
    const data = await response.json();
    renderUrlResult(data);
  } catch (err) {
    showUrlError(err.message || "Could not reach Guardian backend.");
  }
}

function renderUrlResult(data) {
  const { safe, riskScore = 0, reason = "No details provided." } = data;

  urlVerdictBanner.classList.remove("safe", "danger");
  urlVerdictBanner.classList.add(safe ? "safe" : "danger");

  urlVerdictIcon.textContent = safe ? "✅" : "🚫";
  urlVerdictLabel.textContent = safe ? "This page looks safe" : "Danger detected";
  urlVerdictReason.textContent = reason;

  const clampedScore = Math.max(0, Math.min(100, riskScore));
  riskMeterFill.style.width = `${clampedScore}%`;
  riskMeterFill.style.background = safe ? "var(--safe)" : "var(--danger)";
  riskScoreLabel.textContent = `Risk score: ${clampedScore}/100`;

  urlLoading.classList.add("hidden");
  urlError.classList.add("hidden");
  urlResult.classList.remove("hidden");
  urlRecheckBtn.classList.remove("hidden");
}

function showUrlLoading() {
  urlLoading.classList.remove("hidden");
  urlResult.classList.add("hidden");
  urlError.classList.add("hidden");
  urlRecheckBtn.classList.add("hidden");
}

function showUrlError(message) {
  urlErrorText.textContent = message;
  urlLoading.classList.add("hidden");
  urlResult.classList.add("hidden");
  urlError.classList.remove("hidden");
  urlRecheckBtn.classList.remove("hidden");
}

function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      resolve(tabs && tabs[0]);
    });
  });
}

// =============================================================================
// FEATURE 2: Malicious File Scanner (auth required)
// =============================================================================

async function restoreAuthState() {
  const { guardianToken, guardianEmail } = await storageGet([
    "guardianToken",
    "guardianEmail",
  ]);

  if (guardianToken) {
    showScanView(guardianEmail);
  } else {
    showLoginView();
  }
}

async function handleLogin(evt) {
  evt.preventDefault();
  loginError.classList.add("hidden");
  setLoginLoading(true);

  const email = loginEmail.value.trim();
  const password = loginPassword.value;

  try {
    const response = await fetch(ENDPOINTS.login, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      // Try to surface a backend-provided error message if present
      let message = "Invalid email or password.";
      try {
        const errBody = await response.json();
        if (errBody && errBody.message) message = errBody.message;
      } catch (_) {
        /* ignore parse errors, fall back to default message */
      }
      throw new Error(message);
    }

    // Expected shape: { token: "jwt_token_here" }
    const data = await response.json();
    if (!data.token) {
      throw new Error("Login succeeded but no token was returned.");
    }

    await storageSet({ guardianToken: data.token, guardianEmail: email });
    loginPassword.value = "";
    showScanView(email);
  } catch (err) {
    loginErrorText.textContent = err.message || "Login failed.";
    loginError.classList.remove("hidden");
  } finally {
    setLoginLoading(false);
  }
}

async function handleLogout() {
  await storageRemove(["guardianToken", "guardianEmail"]);
  selectedFile = null;
  fileInput.value = "";
  resetScanUI();
  showLoginView();
}

function handleFileSelected() {
  const file = fileInput.files && fileInput.files[0];
  selectedFile = file || null;

  scanResult.classList.add("hidden");
  scanError.classList.add("hidden");

  if (selectedFile) {
    fileDropText.textContent = selectedFile.name;
    fileDropLabel.classList.add("has-file");
    scanBtn.disabled = false;
  } else {
    fileDropText.textContent = "Click to choose a file to scan";
    fileDropLabel.classList.remove("has-file");
    scanBtn.disabled = true;
  }
}

async function handleScanFile() {
  if (!selectedFile) return;

  scanBtn.disabled = true;
  scanResult.classList.add("hidden");
  scanError.classList.add("hidden");
  scanLoading.classList.remove("hidden");

  try {
    const { guardianToken } = await storageGet(["guardianToken"]);
    if (!guardianToken) {
      throw new Error("Session expired. Please log in again.");
    }

    const formData = new FormData();
    formData.append("file", selectedFile);

    const response = await fetch(ENDPOINTS.scan, {
      method: "POST",
      headers: {
        // NOTE: Do NOT set Content-Type manually for multipart/form-data —
        // the browser sets the correct boundary automatically.
        Authorization: `Bearer ${guardianToken}`,
      },
      body: formData,
    });

    if (response.status === 401 || response.status === 403) {
      await storageRemove(["guardianToken", "guardianEmail"]);
      showLoginView();
      throw new Error("Session expired. Please log in again.");
    }

    if (!response.ok) {
      throw new Error(`Backend returned status ${response.status}`);
    }

    // Expected shape:
    // { filename, claimedType, detectedType, verdict: "ACCEPTED"|"REJECTED", reason }
    const data = await response.json();
    renderScanResult(data);
  } catch (err) {
    scanErrorText.textContent = err.message || "File scan failed.";
    scanError.classList.remove("hidden");
  } finally {
    scanLoading.classList.add("hidden");
    scanBtn.disabled = false;
  }
}

function renderScanResult(data) {
  const {
    filename = "unknown",
    claimedType = "unknown",
    detectedType = "unknown",
    verdict = "REJECTED",
    reason = "No details provided.",
  } = data;

  const isAccepted = verdict === "ACCEPTED";

  scanVerdictBanner.classList.remove("safe", "danger");
  scanVerdictBanner.classList.add(isAccepted ? "safe" : "danger");

  scanVerdictIcon.textContent = isAccepted ? "✅" : "🚫";
  scanVerdictLabel.textContent = isAccepted ? "ACCEPTED" : "REJECTED";
  scanVerdictReason.textContent = reason;

  scanFilename.textContent = filename;
  scanClaimedType.textContent = claimedType;
  scanDetectedType.textContent = detectedType;

  scanResult.classList.remove("hidden");
}

function resetScanUI() {
  scanResult.classList.add("hidden");
  scanError.classList.add("hidden");
  scanLoading.classList.add("hidden");
  fileDropText.textContent = "Click to choose a file to scan";
  fileDropLabel.classList.remove("has-file");
  scanBtn.disabled = true;
}

function setLoginLoading(isLoading) {
  loginBtn.disabled = isLoading;
  loginBtn.textContent = isLoading ? "Logging in…" : "Log In";
}

function showLoginView() {
  loginView.classList.remove("hidden");
  scanView.classList.add("hidden");
}

function showScanView(email) {
  loginView.classList.add("hidden");
  scanView.classList.remove("hidden");
  loggedInAs.textContent = email ? `Signed in as ${email}` : "";
  resetScanUI();
}

// ---------------------------------------------------------------------------
// chrome.storage helpers (promise wrappers)
// ---------------------------------------------------------------------------
function storageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, (result) => resolve(result));
  });
}

function storageSet(items) {
  return new Promise((resolve) => {
    chrome.storage.local.set(items, () => resolve());
  });
}

function storageRemove(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.remove(keys, () => resolve());
  });
}
