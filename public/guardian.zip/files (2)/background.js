/* =========================================================================
 * Guardian Security Suite — background.js (Manifest V3 service worker)
 *
 * This runs independently of the popup. Whenever the active tab finishes
 * loading a new URL, we silently call the phishing-check endpoint and set
 * the toolbar badge to green (safe) or red (danger) with the risk score,
 * so the user gets a signal without even opening the popup.
 *
 * >>> REPLACE <MY_VERCEL_URL> BELOW WITH YOUR ACTUAL DEPLOYED BACKEND URL <<<
 * (Keep this in sync with the value in popup.js)
 * ========================================================================= */
const API_BASE_URL = "https://guradian.vercel.app/";
const CHECK_URL_ENDPOINT = `${API_BASE_URL}/api/check-url`;

// Only scan real web pages, skip chrome://, extension pages, etc.
function isScannableUrl(url) {
  return typeof url === "string" && /^https?:\/\//i.test(url);
}

async function scanAndUpdateBadge(tabId, url) {
  if (!tabId || !isScannableUrl(url)) {
    chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }

  try {
    const response = await fetch(CHECK_URL_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });

    if (!response.ok) {
      throw new Error(`Status ${response.status}`);
    }

    // Expected shape: { safe: false, riskScore: 85, reason: "..." }
    const data = await response.json();
    const safe = !!data.safe;

    chrome.action.setBadgeText({ tabId, text: safe ? "OK" : "!" });
    chrome.action.setBadgeBackgroundColor({
      tabId,
      color: safe ? "#2ecc71" : "#ff5c5c",
    });
  } catch (err) {
    // Backend unreachable or errored — clear badge rather than show stale info
    chrome.action.setBadgeText({ tabId, text: "" });
    console.warn("Guardian: URL check failed", err);
  }
}

// Re-scan whenever a tab finishes loading a new page
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete") {
    scanAndUpdateBadge(tabId, tab.url);
  }
});

// Re-scan whenever the user switches to a different tab
chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) return;
    scanAndUpdateBadge(tabId, tab.url);
  });
});
